<footer>
    <!--
    This is an example of using PHP's shorthand tag. The shorthand tag replaces
    the word 'echo'. 
    -->
    <?= "<small>Updated by: Charlie Wallin, " . date("F j, Y") . "</small>"; ?>
</footer>
</body>
</html>