<!DOCTYPE html>
<!--	Author: Chalie Wallin
		Date:	3/30/20
		File:	raises.php
		Purpose:MySQL Exercise
-->

<html>
<head>
	<title><?= ($page_title); ?></title>
	<link rel ="stylesheet" type="text/css" href="sample.css">
</head>

<body>