<?php
// The initialize file reduces redundancy in the code and can 
// be reused for all of the exercises

include_once("includes/header.php");
include_once("database/connection.php");
include_once("database/errors.php");
include_once("database/queries.php");
